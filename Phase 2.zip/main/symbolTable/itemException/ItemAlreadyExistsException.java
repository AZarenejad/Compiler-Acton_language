package main.symbolTable.itemException;

import main.compileError.CompileErrorException;

public class ItemAlreadyExistsException extends CompileErrorException {
}