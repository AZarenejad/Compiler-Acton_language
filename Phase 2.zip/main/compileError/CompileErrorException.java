package main.compileError;

public class CompileErrorException extends Exception {
}
