package main.ast.node.expression.operators;

public enum BinaryOperator {
    assign, eq, neq, gt, lt, add, sub, mult, div, mod, and, or
}
