package main.ast.node.declaration;

import main.ast.node.Node;

public abstract class Declaration extends Node {
}